
from pathlib import Path
import json
import html
import joblib
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

BASE = Path(__file__).resolve().parent
MODEL = joblib.load(BASE / "rocket_model.pkl")
META = json.loads((BASE / "model_metadata.json").read_text(encoding="utf-8"))

st.set_page_config(
    page_title="AstraSim | Rocket Propulsion Validator",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;600;700&display=swap');

:root {
    --space: #050816;
    --panel: rgba(12, 20, 43, 0.86);
    --line: rgba(255, 143, 99, 0.28);
    --orange: #ff8f63;
    --salmon: #ff6f61;
    --cream: #fff3e8;
    --muted: #aab3ca;
}

.stApp {
    background:
      radial-gradient(circle at 75% 15%, rgba(71, 91, 173, .22), transparent 30%),
      radial-gradient(circle at 20% 80%, rgba(255, 111, 97, .13), transparent 28%),
      linear-gradient(145deg, #040712 0%, #081126 55%, #03050d 100%);
    color: var(--cream);
}

[data-testid="stSidebar"] {
    background: linear-gradient(180deg, rgba(7, 12, 27, .98), rgba(12, 20, 43, .98));
    border-right: 1px solid var(--line);
}

h1, h2, h3 {
    font-family: 'Orbitron', sans-serif !important;
    letter-spacing: .03em;
}

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.hero {
    border: 1px solid var(--line);
    border-radius: 24px;
    padding: 28px 30px;
    background: linear-gradient(135deg, rgba(15, 26, 55, .92), rgba(8, 13, 31, .78));
    box-shadow: 0 22px 60px rgba(0,0,0,.35);
    margin-bottom: 18px;
}

.hero-kicker {
    color: var(--orange);
    font-weight: 700;
    letter-spacing: .18em;
    font-size: .78rem;
}

.hero-title {
    font-family: 'Orbitron', sans-serif;
    font-size: clamp(2rem, 5vw, 4rem);
    font-weight: 700;
    margin: 4px 0 2px;
    background: linear-gradient(90deg, #fff3e8, #ffb18c);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.hero-subtitle {
    color: var(--muted);
    max-width: 850px;
    font-size: 1.02rem;
}

.status-card {
    border: 1px solid var(--line);
    border-radius: 18px;
    padding: 18px;
    background: var(--panel);
    min-height: 138px;
}

.metric-label {
    color: var(--muted);
    font-size: .78rem;
    letter-spacing: .10em;
    text-transform: uppercase;
}

.metric-value {
    font-family: 'Orbitron', sans-serif;
    font-size: 1.45rem;
    font-weight: 700;
    margin-top: 8px;
}

.good { color: #6ee7b7; }
.bad { color: #ff7a70; }
.warn { color: #ffc46b; }

div.stButton > button {
    width: 100%;
    border: 1px solid rgba(255, 143, 99, .65);
    border-radius: 14px;
    background: linear-gradient(90deg, #ff6f61, #ff9a62);
    color: #07101f;
    font-family: 'Orbitron', sans-serif;
    font-weight: 700;
    padding: .85rem 1rem;
    box-shadow: 0 10px 30px rgba(255,111,97,.22);
}

div.stButton > button:hover {
    border-color: #ffd1bd;
    transform: translateY(-1px);
}

[data-testid="stMetric"] {
    background: rgba(12, 20, 43, .76);
    border: 1px solid var(--line);
    padding: 14px 16px;
    border-radius: 16px;
}

.small-note {
    color: var(--muted);
    font-size: .82rem;
    line-height: 1.5;
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <div class="hero-kicker">AI-POWERED PROPULSION ANALYSIS</div>
  <div class="hero-title">ASTRASIM</div>
  <div class="hero-subtitle">
    Configure a simulated rocket propulsion system, initiate the test, and let a tuned XGBoost
    classifier estimate whether the configuration contains a potential physics violation.
  </div>
</div>
""", unsafe_allow_html=True)

ranges = META["numeric_ranges"]

with st.sidebar:
    st.header("Engine configuration")
    fuel = st.selectbox("Fuel type", META["fuel_types"])
    oxidizer = st.selectbox("Oxidizer type", META["oxidizer_types"])

    chamber_pressure = st.slider(
        "Chamber pressure (bar)",
        float(ranges["chamber_pressure_bar"]["min"]),
        float(ranges["chamber_pressure_bar"]["max"]),
        float(ranges["chamber_pressure_bar"]["median"]),
    )
    of_ratio = st.slider(
        "Oxidizer-to-fuel ratio",
        float(ranges["oxidizer_fuel_ratio"]["min"]),
        float(ranges["oxidizer_fuel_ratio"]["max"]),
        float(ranges["oxidizer_fuel_ratio"]["median"]),
    )
    combustion_temp = st.slider(
        "Combustion temperature (K)",
        float(ranges["combustion_temperature_K"]["min"]),
        float(ranges["combustion_temperature_K"]["max"]),
        float(ranges["combustion_temperature_K"]["median"]),
    )
    heat_ratio = st.slider(
        "Heat-capacity ratio",
        float(ranges["heat_capacity_ratio"]["min"]),
        float(ranges["heat_capacity_ratio"]["max"]),
        float(ranges["heat_capacity_ratio"]["median"]),
        step=0.001,
    )
    expansion_ratio = st.slider(
        "Nozzle expansion ratio",
        float(ranges["nozzle_expansion_ratio"]["min"]),
        float(ranges["nozzle_expansion_ratio"]["max"]),
        float(ranges["nozzle_expansion_ratio"]["median"]),
    )
    ambient_pressure = st.slider(
        "Ambient pressure (bar)",
        float(ranges["ambient_pressure_bar"]["min"]),
        float(ranges["ambient_pressure_bar"]["max"]),
        float(ranges["ambient_pressure_bar"]["median"]),
        step=0.001,
    )
    specific_impulse = st.slider(
        "Specific impulse (s)",
        float(ranges["specific_impulse_s"]["min"]),
        float(ranges["specific_impulse_s"]["max"]),
        float(ranges["specific_impulse_s"]["median"]),
    )
    stability_margin = st.slider(
        "Combustion stability margin",
        float(ranges["combustion_stability_margin"]["min"]),
        float(ranges["combustion_stability_margin"]["max"]),
        float(ranges["combustion_stability_margin"]["median"]),
        step=0.001,
    )

    launch = st.button("INITIATE ENGINE TEST", type="primary")
    st.markdown(
        '<div class="small-note">This is an educational machine-learning simulation, not an engineering certification or launch-safety tool.</div>',
        unsafe_allow_html=True,
    )

inputs = pd.DataFrame([{
    "fuel_type": fuel,
    "oxidizer_type": oxidizer,
    "chamber_pressure_bar": chamber_pressure,
    "oxidizer_fuel_ratio": of_ratio,
    "combustion_temperature_K": combustion_temp,
    "heat_capacity_ratio": heat_ratio,
    "nozzle_expansion_ratio": expansion_ratio,
    "ambient_pressure_bar": ambient_pressure,
    "specific_impulse_s": specific_impulse,
    "combustion_stability_margin": stability_margin,
}])

if "tested" not in st.session_state:
    st.session_state.tested = False
if launch:
    st.session_state.tested = True

probability = float(MODEL.predict_proba(inputs)[0, 1])
prediction = int(probability >= META.get("decision_threshold", 0.5))
confidence = probability if prediction == 1 else 1 - probability

status = "POTENTIAL PHYSICS VIOLATION" if prediction else "NO VIOLATION DETECTED"
status_class = "bad" if prediction else "good"
rocket_state = "failure" if prediction else ("launch" if st.session_state.tested else "idle")

rocket_html = f"""
<!doctype html>
<html>
<head>
<style>
* {{ box-sizing: border-box; }}
body {{
  margin: 0;
  overflow: hidden;
  background:
    radial-gradient(circle at 18% 20%, rgba(255,255,255,.95) 0 1px, transparent 2px),
    radial-gradient(circle at 78% 16%, rgba(255,255,255,.8) 0 1px, transparent 2px),
    radial-gradient(circle at 70% 62%, rgba(255,255,255,.8) 0 1px, transparent 2px),
    radial-gradient(circle at 32% 72%, rgba(255,255,255,.7) 0 1px, transparent 2px),
    linear-gradient(180deg, #060a18, #101d3f 75%, #18233a);
  font-family: Arial, sans-serif;
}}
.scene {{
  height: 510px;
  position: relative;
  border-radius: 22px;
  border: 1px solid rgba(255,143,99,.32);
  overflow: hidden;
}}
.glow {{
  position: absolute;
  width: 300px; height: 300px;
  left: 50%; top: 48%;
  transform: translate(-50%,-50%);
  background: radial-gradient(circle, rgba(84,118,255,.26), transparent 68%);
}}
.rocket-wrap {{
  position: absolute;
  left: 50%;
  bottom: 72px;
  transform: translateX(-50%);
}}
.rocket {{
  width: 128px;
  height: 300px;
  position: relative;
  filter: drop-shadow(0 18px 24px rgba(0,0,0,.42));
}}
.nose {{
  position: absolute;
  top: 0; left: 24px;
  width: 80px; height: 92px;
  background: linear-gradient(90deg, #d7dce7, #ffffff 48%, #a8b0c4);
  clip-path: polygon(50% 0, 100% 100%, 0 100%);
}}
.body {{
  position: absolute;
  top: 76px; left: 24px;
  width: 80px; height: 154px;
  border-radius: 10px 10px 22px 22px;
  background: linear-gradient(90deg, #aeb7c9, #ffffff 44%, #c5ccda 70%, #8d97ad);
  border: 1px solid rgba(255,255,255,.65);
}}
.band {{
  position: absolute;
  top: 157px; left: 24px;
  width: 80px; height: 24px;
  background: linear-gradient(90deg, #ff6f61, #ff9b63);
}}
.window {{
  position: absolute;
  top: 104px; left: 46px;
  width: 36px; height: 36px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 30%, #d8fbff, #3979a8 48%, #112848 75%);
  border: 5px solid #475267;
}}
.fin-left {{
  position: absolute;
  left: 3px; top: 190px;
  width: 45px; height: 84px;
  background: linear-gradient(145deg, #ff8f63, #b83c45);
  clip-path: polygon(100% 0, 100% 100%, 0 100%);
}}
.fin-right {{
  position: absolute;
  right: 3px; top: 190px;
  width: 45px; height: 84px;
  background: linear-gradient(215deg, #ff8f63, #b83c45);
  clip-path: polygon(0 0, 100% 100%, 0 100%);
}}
.nozzle {{
  position: absolute;
  left: 45px; top: 226px;
  width: 38px; height: 32px;
  background: linear-gradient(90deg, #333a4a, #858fa3, #2b3140);
  clip-path: polygon(18% 0, 82% 0, 100% 100%, 0 100%);
}}
.flame {{
  position: absolute;
  left: 43px; top: 250px;
  width: 42px; height: 72px;
  opacity: 0;
  background: linear-gradient(#fff7bf 0 18%, #ffb14a 36%, #ff6248 68%, transparent 100%);
  clip-path: polygon(50% 100%, 5% 15%, 28% 22%, 50% 0, 72% 22%, 95% 15%);
  filter: drop-shadow(0 0 16px #ff6f42);
}}
.pad {{
  position: absolute;
  left: 50%; bottom: 48px;
  transform: translateX(-50%);
  width: 230px; height: 18px;
  border-radius: 50%;
  background: radial-gradient(ellipse, #59657b, #1a2232 70%);
}}
.readout {{
  position: absolute;
  top: 24px; left: 24px; right: 24px;
  display: flex; justify-content: space-between; gap: 10px;
  color: #d9e4ff; font-size: 12px; letter-spacing: .12em;
}}
.badge {{
  padding: 8px 11px;
  border: 1px solid rgba(255,143,99,.35);
  border-radius: 999px;
  background: rgba(7,12,27,.64);
}}
.launch .rocket-wrap {{ animation: liftoff 2.6s ease-in forwards; }}
.launch .flame {{ opacity: 1; animation: flame .13s infinite alternate; }}
.failure .rocket-wrap {{ animation: shake .12s 18 alternate; }}
.failure .flame {{ opacity: .76; animation: sputter .18s 12 alternate; }}
@keyframes liftoff {{
  0% {{ bottom: 72px; }}
  22% {{ bottom: 82px; }}
  100% {{ bottom: 590px; }}
}}
@keyframes flame {{
  from {{ transform: scaleY(.82) scaleX(.92); }}
  to {{ transform: scaleY(1.2) scaleX(1.08); }}
}}
@keyframes shake {{
  from {{ transform: translateX(calc(-50% - 5px)) rotate(-1.5deg); }}
  to {{ transform: translateX(calc(-50% + 5px)) rotate(1.5deg); }}
}}
@keyframes sputter {{
  from {{ transform: scaleY(.35); opacity: .25; }}
  to {{ transform: scaleY(.95); opacity: .9; }}
}}
</style>
</head>
<body>
<div class="scene {rocket_state}">
  <div class="glow"></div>
  <div class="readout">
    <div class="badge">FUEL: {html.escape(str(fuel))}</div>
    <div class="badge">OXIDIZER: {html.escape(str(oxidizer))}</div>
  </div>
  <div class="pad"></div>
  <div class="rocket-wrap">
    <div class="rocket">
      <div class="nose"></div>
      <div class="body"></div>
      <div class="band"></div>
      <div class="window"></div>
      <div class="fin-left"></div>
      <div class="fin-right"></div>
      <div class="nozzle"></div>
      <div class="flame"></div>
    </div>
  </div>
</div>
</body>
</html>
"""

left, right = st.columns([1.35, 1], gap="large")

with left:
    components.html(rocket_html, height=525, scrolling=False)

with right:
    st.subheader("Mission analysis")
    if not st.session_state.tested:
        st.info("Adjust the engine configuration and press **Initiate Engine Test**.")
    else:
        st.markdown(
            f'<div class="status-card"><div class="metric-label">System status</div>'
            f'<div class="metric-value {status_class}">{status}</div>'
            f'<div class="small-note">Model confidence: {confidence:.1%}</div></div>',
            unsafe_allow_html=True,
        )

    c1, c2 = st.columns(2)
    c1.metric("Violation probability", f"{probability:.1%}")
    c2.metric("Safe-class probability", f"{1-probability:.1%}")

    st.progress(probability, text="Predicted physics-violation risk")

    if prediction:
        st.warning(
            "The model found a configuration pattern associated with the physics-violation class. "
            "Review the selected values before treating this configuration as plausible."
        )
    else:
        st.success(
            "The model did not detect a physics violation in this configuration. "
            "This result is only a prediction based on the training dataset."
        )

    with st.expander("View submitted configuration"):
        st.dataframe(inputs.T.rename(columns={0: "Selected value"}), use_container_width=True)

st.divider()
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Model", META["model_name"])
m2.metric("Test recall", f'{META["metrics"]["recall"]:.1%}')
m3.metric("Test precision", f'{META["metrics"]["precision"]:.1%}')
m4.metric("Test F1", f'{META["metrics"]["f1"]:.1%}')
m5.metric("Test AUC", f'{META["metrics"]["roc_auc"]:.3f}')

st.caption(
    "AstraSim is an educational demonstration created from a simulated rocket-propulsion dataset. "
    "It does not replace physical modeling, engineering review, laboratory testing, or safety analysis."
)
