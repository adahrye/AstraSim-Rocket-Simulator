# AstraSim Rocket Propulsion App

This Streamlit application predicts whether a simulated rocket propulsion configuration is associated with a potential physics violation.

## Files

- `app.py` — interactive Streamlit dashboard
- `rocket_model.pkl` — trained preprocessing + tuned XGBoost pipeline
- `model_metadata.json` — input ranges, categories, and evaluation metrics
- `requirements.txt` — deployment dependencies

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Upload all files in this folder to a GitHub repository.
2. In Streamlit Community Cloud, create a new app.
3. Select the repository and choose `app.py` as the main file.
4. Deploy.

## Recovered tuned XGBoost settings

- n_estimators: 100
- learning_rate: 0.01
- max_depth: 3
- subsample: 0.8
- colsample_bytree: 0.8
- reg_alpha: 0
- reg_lambda: 1.0

## Evaluation from this packaged pipeline

- Accuracy: 0.897
- Recall: 0.999
- Precision: 0.736
- F1: 0.847
- ROC-AUC: 0.979

The pipeline was trained on the same reproducible 10% sample strategy used in the uploaded notebook.
