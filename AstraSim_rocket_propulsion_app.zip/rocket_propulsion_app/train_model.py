
from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier

BASE = Path(__file__).resolve().parent
DATA = BASE / "rocket_propulsion_dataset.csv"

df = pd.read_csv(DATA)
target = "physics_violation_flag"
categorical = ["fuel_type", "oxidizer_type"]
numeric = [
    "chamber_pressure_bar", "oxidizer_fuel_ratio",
    "combustion_temperature_K", "heat_capacity_ratio",
    "nozzle_expansion_ratio", "ambient_pressure_bar",
    "specific_impulse_s", "combustion_stability_margin"
]

sample = df.sample(frac=0.10, random_state=42)
X = sample[categorical + numeric]
y = sample[target]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

preprocessor = ColumnTransformer([
    ("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False), categorical),
    ("numeric", "passthrough", numeric),
])

neg = (y_train == 0).sum()
pos = (y_train == 1).sum()

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", XGBClassifier(
        n_estimators=100, learning_rate=0.01, max_depth=3,
        subsample=0.8, colsample_bytree=0.8,
        reg_alpha=0, reg_lambda=1.0,
        scale_pos_weight=neg / pos,
        eval_metric="logloss", random_state=42, n_jobs=-1
    )),
])

model.fit(X_train, y_train)
joblib.dump(model, BASE / "rocket_model.pkl")
print("Saved rocket_model.pkl")
